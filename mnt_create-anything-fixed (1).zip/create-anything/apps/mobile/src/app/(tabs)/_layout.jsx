import { Tabs } from "expo-router";
import { Home, List, MapPin, Clock, Heart } from "lucide-react-native";
import { useColorScheme } from "react-native";

export default function TabLayout() {
  const colorScheme = useColorScheme();
  const isDark = colorScheme === "dark";

  const colors = {
    background: isDark ? "#121212" : "#FFFFFF",
    primary: isDark ? "#6B46C1" : "#10B981",
    textSecondary: isDark ? "rgba(255, 255, 255, 0.60)" : "#9E9E9E",
    border: isDark ? "#404040" : "#E6E6E6",
  };

  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        tabBarStyle: {
          backgroundColor: colors.background,
          borderTopWidth: 1,
          borderTopColor: colors.border,
          paddingTop: 4,
        },
        tabBarActiveTintColor: colors.primary,
        tabBarInactiveTintColor: colors.textSecondary,
        tabBarLabelStyle: {
          fontSize: 12,
          fontFamily: "Poppins_500Medium",
        },
      }}
    >
      <Tabs.Screen
        name="index"
        options={{
          title: "主頁",
          tabBarIcon: ({ color, size }) => <Home color={color} size={24} />,
        }}
      />
      <Tabs.Screen
        name="routes"
        options={{
          title: "路線",
          tabBarIcon: ({ color, size }) => <List color={color} size={24} />,
        }}
      />
      <Tabs.Screen
        name="nearby"
        options={{
          title: "附近",
          tabBarIcon: ({ color, size }) => <MapPin color={color} size={24} />,
        }}
      />
      <Tabs.Screen
        name="recent"
        options={{
          title: "最近",
          tabBarIcon: ({ color, size }) => <Clock color={color} size={24} />,
        }}
      />
      <Tabs.Screen
        name="favorites"
        options={{
          title: "收藏",
          tabBarIcon: ({ color, size }) => <Heart color={color} size={24} />,
        }}
      />
    </Tabs>
  );
}
