import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  StyleSheet,
  ActivityIndicator,
  Alert,
  useColorScheme,
} from "react-native";
import { StatusBar } from "expo-status-bar";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import {
  useFonts,
  Poppins_400Regular,
  Poppins_500Medium,
  Poppins_600SemiBold,
  Poppins_700Bold,
} from "@expo-google-fonts/poppins";
import { MapPin, RefreshCw } from "lucide-react-native";
import * as Location from "expo-location";
import { useQuery } from "@tanstack/react-query";

export default function NearbyScreen() {
  const insets = useSafeAreaInsets();
  const colorScheme = useColorScheme();
  const isDark = colorScheme === "dark";

  const theme = {
    isDark,
    colors: {
      background: isDark ? "#121212" : "#FFFFFF",
      surface: isDark ? "#1E1E1E" : "#FFFFFF",
      surfaceElevated: isDark ? "#262626" : "#F5F5F5",
      text: isDark ? "rgba(255, 255, 255, 0.87)" : "#1A1A1A",
      textSecondary: isDark ? "rgba(255, 255, 255, 0.60)" : "#9E9E9E",
      textTertiary: isDark ? "rgba(255, 255, 255, 0.38)" : "#C0C0C0",
      primary: isDark ? "#6B46C1" : "#10B981",
      border: isDark ? "#404040" : "#E6E6E6",
    },
  };

  const [location, setLocation] = useState(null);
  const [locationError, setLocationError] = useState(null);

  const [fontsLoaded] = useFonts({
    Poppins_400Regular,
    Poppins_500Medium,
    Poppins_600SemiBold,
    Poppins_700Bold,
  });

  useEffect(() => {
    getLocation();
  }, []);

  const getLocation = async () => {
    try {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== "granted") {
        setLocationError("需要位置權限才能顯示附近車站");
        return;
      }

      const currentLocation = await Location.getCurrentPositionAsync({});
      setLocation({
        lat: currentLocation.coords.latitude,
        long: currentLocation.coords.longitude,
      });
      setLocationError(null);
    } catch (error) {
      console.error("Error getting location:", error);
      setLocationError("無法獲取位置");
    }
  };

  const {
    data: nearbyStops,
    isLoading,
    refetch,
  } = useQuery({
    queryKey: ["nearbyStops", location?.lat, location?.long],
    queryFn: async () => {
      if (!location) return [];
      const response = await fetch(
        `/api/bus/nearby-stops?lat=${location.lat}&long=${location.long}&radius=500`,
      );
      if (!response.ok) throw new Error("Failed to fetch nearby stops");
      const result = await response.json();
      return result.data || [];
    },
    enabled: !!location,
  });

  if (!fontsLoaded) {
    return null;
  }

  const handleRefresh = () => {
    getLocation();
    if (location) {
      refetch();
    }
  };

  return (
    <View
      style={[
        styles.container,
        { backgroundColor: theme.colors.background, paddingTop: insets.top },
      ]}
    >
      <StatusBar style={theme.isDark ? "light" : "dark"} />

      <View style={styles.header}>
        <View>
          <Text style={[styles.title, { color: theme.colors.text }]}>
            附近車站
          </Text>
          <Text
            style={[styles.subtitle, { color: theme.colors.textSecondary }]}
          >
            {nearbyStops?.length || 0} 個車站（500米內）
          </Text>
        </View>
        <TouchableOpacity
          style={[
            styles.refreshButton,
            { backgroundColor: theme.colors.surfaceElevated },
          ]}
          onPress={handleRefresh}
          activeOpacity={0.7}
        >
          <RefreshCw size={20} color={theme.colors.text} />
        </TouchableOpacity>
      </View>

      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={[
          styles.scrollContent,
          { paddingBottom: insets.bottom + 20 },
        ]}
        showsVerticalScrollIndicator={false}
      >
        {locationError ? (
          <View style={styles.errorContainer}>
            <MapPin size={48} color={theme.colors.textTertiary} />
            <Text style={[styles.errorText, { color: theme.colors.text }]}>
              {locationError}
            </Text>
            <TouchableOpacity
              style={[
                styles.retryButton,
                { backgroundColor: theme.colors.primary },
              ]}
              onPress={getLocation}
              activeOpacity={0.7}
            >
              <Text
                style={[
                  styles.retryButtonText,
                  { color: theme.isDark ? theme.colors.text : "#FFFFFF" },
                ]}
              >
                重新獲取位置
              </Text>
            </TouchableOpacity>
          </View>
        ) : isLoading ? (
          <ActivityIndicator
            size="large"
            color={theme.colors.primary}
            style={styles.loader}
          />
        ) : nearbyStops && nearbyStops.length > 0 ? (
          nearbyStops.map((stop, index) => (
            <View
              key={`${stop.stop}-${index}`}
              style={[
                styles.stopCard,
                {
                  backgroundColor: theme.colors.surface,
                  borderColor: theme.colors.border,
                },
              ]}
            >
              <View style={styles.stopHeader}>
                <View
                  style={[
                    styles.companyBadge,
                    {
                      backgroundColor:
                        stop.company === "KMB" ? "#10B981" : "#3B82F6",
                    },
                  ]}
                >
                  <Text style={styles.companyText}>{stop.company}</Text>
                </View>
                <View
                  style={[
                    styles.distanceBadge,
                    { backgroundColor: theme.colors.surfaceElevated },
                  ]}
                >
                  <Text
                    style={[styles.distanceText, { color: theme.colors.text }]}
                  >
                    {stop.distance}米
                  </Text>
                </View>
              </View>
              <Text style={[styles.stopName, { color: theme.colors.text }]}>
                {stop.name_tc}
              </Text>
              <Text
                style={[
                  styles.stopNameEn,
                  { color: theme.colors.textSecondary },
                ]}
              >
                {stop.name_en}
              </Text>
            </View>
          ))
        ) : (
          <View style={styles.emptyContainer}>
            <MapPin size={48} color={theme.colors.textTertiary} />
            <Text style={[styles.emptyText, { color: theme.colors.text }]}>
              附近沒有車站
            </Text>
          </View>
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: 24,
    paddingTop: 20,
    paddingBottom: 16,
  },
  title: {
    fontFamily: "Poppins_700Bold",
    fontSize: 32,
    marginBottom: 4,
  },
  subtitle: {
    fontFamily: "Poppins_400Regular",
    fontSize: 16,
  },
  refreshButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    justifyContent: "center",
    alignItems: "center",
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    paddingHorizontal: 24,
  },
  loader: {
    marginTop: 40,
  },
  stopCard: {
    padding: 16,
    borderRadius: 12,
    borderWidth: 1,
    marginBottom: 12,
  },
  stopHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 12,
  },
  companyBadge: {
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 6,
  },
  companyText: {
    fontFamily: "Poppins_600SemiBold",
    fontSize: 12,
    color: "#FFFFFF",
  },
  distanceBadge: {
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 6,
  },
  distanceText: {
    fontFamily: "Poppins_500Medium",
    fontSize: 12,
  },
  stopName: {
    fontFamily: "Poppins_600SemiBold",
    fontSize: 16,
    marginBottom: 4,
  },
  stopNameEn: {
    fontFamily: "Poppins_400Regular",
    fontSize: 14,
  },
  errorContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    paddingTop: 60,
  },
  errorText: {
    fontFamily: "Poppins_500Medium",
    fontSize: 16,
    marginTop: 16,
    marginBottom: 24,
  },
  retryButton: {
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 12,
  },
  retryButtonText: {
    fontFamily: "Poppins_600SemiBold",
    fontSize: 16,
  },
  emptyContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    paddingTop: 60,
  },
  emptyText: {
    fontFamily: "Poppins_500Medium",
    fontSize: 16,
    marginTop: 16,
  },
});
