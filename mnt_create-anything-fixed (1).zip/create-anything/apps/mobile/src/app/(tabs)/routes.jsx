import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  TextInput,
  ScrollView,
  TouchableOpacity,
  StyleSheet,
  ActivityIndicator,
  useColorScheme,
} from "react-native";
import { StatusBar } from "expo-status-bar";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import {
  useFonts,
  Poppins_400Regular,
  Poppins_500Medium,
  Poppins_600SemiBold,
  Poppins_700Bold,
} from "@expo-google-fonts/poppins";
import { Search, Heart } from "lucide-react-native";
import { useRouter } from "expo-router";
import { useQuery } from "@tanstack/react-query";
import * as SecureStore from "expo-secure-store";

export default function RoutesScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const colorScheme = useColorScheme();
  const isDark = colorScheme === "dark";

  const theme = {
    isDark,
    colors: {
      background: isDark ? "#121212" : "#FFFFFF",
      surface: isDark ? "#1E1E1E" : "#FFFFFF",
      surfaceElevated: isDark ? "#262626" : "#F5F5F5",
      text: isDark ? "rgba(255, 255, 255, 0.87)" : "#1A1A1A",
      textSecondary: isDark ? "rgba(255, 255, 255, 0.60)" : "#9E9E9E",
      primary: isDark ? "#6B46C1" : "#10B981",
      border: isDark ? "#404040" : "#E6E6E6",
    },
  };

  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCompany, setSelectedCompany] = useState("ALL");
  const [favorites, setFavorites] = useState([]);

  const [fontsLoaded] = useFonts({
    Poppins_400Regular,
    Poppins_500Medium,
    Poppins_600SemiBold,
    Poppins_700Bold,
  });

  useEffect(() => {
    loadFavorites();
  }, []);

  const loadFavorites = async () => {
    try {
      const stored = await SecureStore.getItemAsync("favorites");
      if (stored) {
        setFavorites(JSON.parse(stored));
      }
    } catch (error) {
      console.error("Error loading favorites:", error);
    }
  };

  const toggleFavorite = async (routeId) => {
    try {
      let newFavorites;
      if (favorites.includes(routeId)) {
        newFavorites = favorites.filter((id) => id !== routeId);
      } else {
        newFavorites = [...favorites, routeId];
      }
      setFavorites(newFavorites);
      await SecureStore.setItemAsync("favorites", JSON.stringify(newFavorites));
    } catch (error) {
      console.error("Error toggling favorite:", error);
    }
  };

  const { data: routesData, isLoading } = useQuery({
    queryKey: ["routes"],
    queryFn: async () => {
      const response = await fetch("/api/bus/routes");
      if (!response.ok) throw new Error("Failed to fetch routes");
      const result = await response.json();
      return result.data || [];
    },
  });

  if (!fontsLoaded) {
    return null;
  }

  const filteredRoutes =
    routesData?.filter((route) => {
      const matchesCompany =
        selectedCompany === "ALL" || route.company === selectedCompany;
      if (!searchQuery) return matchesCompany;

      const query = searchQuery.toLowerCase();
      const matchesSearch =
        route.route.toLowerCase().includes(query) ||
        route.orig_tc.includes(searchQuery) ||
        route.dest_tc.includes(searchQuery) ||
        route.orig_en.toLowerCase().includes(query) ||
        route.dest_en.toLowerCase().includes(query);

      return matchesCompany && matchesSearch;
    }) || [];

  const handleRoutePress = (route) => {
    router.push(`/route/${route.id}`);
  };

  return (
    <View
      style={[
        styles.container,
        { backgroundColor: theme.colors.background, paddingTop: insets.top },
      ]}
    >
      <StatusBar style={theme.isDark ? "light" : "dark"} />

      <View style={styles.header}>
        <Text style={[styles.title, { color: theme.colors.text }]}>
          所有路線
        </Text>
        <Text style={[styles.subtitle, { color: theme.colors.textSecondary }]}>
          {filteredRoutes.length} 條路線
        </Text>
      </View>

      <View
        style={[
          styles.searchContainer,
          { backgroundColor: theme.colors.surfaceElevated },
        ]}
      >
        <Search size={20} color={theme.colors.textSecondary} />
        <TextInput
          style={[styles.searchInput, { color: theme.colors.text }]}
          placeholder="搜尋路線"
          placeholderTextColor={theme.colors.textSecondary}
          value={searchQuery}
          onChangeText={setSearchQuery}
        />
      </View>

      <View style={styles.filterContainer}>
        {["ALL", "KMB", "CTB"].map((company) => (
          <TouchableOpacity
            key={company}
            style={[
              styles.filterChip,
              {
                backgroundColor:
                  selectedCompany === company
                    ? theme.colors.primary
                    : theme.colors.surfaceElevated,
              },
            ]}
            onPress={() => setSelectedCompany(company)}
            activeOpacity={0.7}
          >
            <Text
              style={[
                styles.filterText,
                {
                  color:
                    selectedCompany === company
                      ? theme.isDark
                        ? theme.colors.text
                        : "#FFFFFF"
                      : theme.colors.textSecondary,
                },
              ]}
            >
              {company === "ALL" ? "全部" : company}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={[
          styles.scrollContent,
          { paddingBottom: insets.bottom + 20 },
        ]}
        showsVerticalScrollIndicator={false}
      >
        {isLoading ? (
          <ActivityIndicator
            size="large"
            color={theme.colors.primary}
            style={styles.loader}
          />
        ) : (
          filteredRoutes.map((route) => (
            <TouchableOpacity
              key={route.id}
              style={[
                styles.routeItem,
                {
                  backgroundColor: theme.colors.surface,
                  borderColor: theme.colors.border,
                },
              ]}
              onPress={() => handleRoutePress(route)}
              activeOpacity={0.7}
            >
              <View style={styles.routeLeft}>
                <View
                  style={[
                    styles.routeBadge,
                    {
                      backgroundColor:
                        route.company === "KMB" ? "#10B981" : "#3B82F6",
                    },
                  ]}
                >
                  <Text style={styles.routeNumber}>{route.route}</Text>
                </View>
                <View style={styles.routeInfo}>
                  <Text
                    style={[styles.routeText, { color: theme.colors.text }]}
                    numberOfLines={1}
                  >
                    {route.orig_tc} → {route.dest_tc}
                  </Text>
                  <Text
                    style={[
                      styles.routeCompany,
                      { color: theme.colors.textSecondary },
                    ]}
                  >
                    {route.company}
                  </Text>
                </View>
              </View>
              <TouchableOpacity
                onPress={() => toggleFavorite(route.id)}
                hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
              >
                <Heart
                  size={20}
                  color={
                    favorites.includes(route.id)
                      ? "#EF4444"
                      : theme.colors.textSecondary
                  }
                  fill={
                    favorites.includes(route.id) ? "#EF4444" : "transparent"
                  }
                />
              </TouchableOpacity>
            </TouchableOpacity>
          ))
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    paddingHorizontal: 24,
    paddingTop: 20,
    paddingBottom: 16,
  },
  title: {
    fontFamily: "Poppins_700Bold",
    fontSize: 32,
    marginBottom: 4,
  },
  subtitle: {
    fontFamily: "Poppins_400Regular",
    fontSize: 16,
  },
  searchContainer: {
    flexDirection: "row",
    alignItems: "center",
    marginHorizontal: 24,
    marginBottom: 16,
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderRadius: 12,
  },
  searchInput: {
    flex: 1,
    marginLeft: 12,
    fontFamily: "Poppins_400Regular",
    fontSize: 16,
  },
  filterContainer: {
    flexDirection: "row",
    paddingHorizontal: 24,
    marginBottom: 16,
    gap: 8,
  },
  filterChip: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
  },
  filterText: {
    fontFamily: "Poppins_500Medium",
    fontSize: 14,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    paddingHorizontal: 24,
  },
  loader: {
    marginTop: 40,
  },
  routeItem: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    padding: 16,
    borderRadius: 12,
    borderWidth: 1,
    marginBottom: 12,
  },
  routeLeft: {
    flexDirection: "row",
    alignItems: "center",
    flex: 1,
  },
  routeBadge: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 8,
    marginRight: 12,
  },
  routeNumber: {
    fontFamily: "Poppins_700Bold",
    fontSize: 16,
    color: "#FFFFFF",
  },
  routeInfo: {
    flex: 1,
  },
  routeText: {
    fontFamily: "Poppins_500Medium",
    fontSize: 14,
    marginBottom: 4,
  },
  routeCompany: {
    fontFamily: "Poppins_400Regular",
    fontSize: 12,
  },
});
