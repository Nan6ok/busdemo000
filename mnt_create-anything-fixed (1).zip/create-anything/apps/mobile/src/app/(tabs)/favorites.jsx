import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  StyleSheet,
  useColorScheme,
} from "react-native";
import { StatusBar } from "expo-status-bar";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import {
  useFonts,
  Poppins_400Regular,
  Poppins_500Medium,
  Poppins_600SemiBold,
  Poppins_700Bold,
} from "@expo-google-fonts/poppins";
import { Heart } from "lucide-react-native";
import { useRouter } from "expo-router";
import * as SecureStore from "expo-secure-store";
import { useQuery } from "@tanstack/react-query";

export default function FavoritesScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const colorScheme = useColorScheme();
  const isDark = colorScheme === "dark";

  const theme = {
    isDark,
    colors: {
      background: isDark ? "#121212" : "#FFFFFF",
      surface: isDark ? "#1E1E1E" : "#FFFFFF",
      surfaceElevated: isDark ? "#262626" : "#F5F5F5",
      text: isDark ? "rgba(255, 255, 255, 0.87)" : "#1A1A1A",
      textSecondary: isDark ? "rgba(255, 255, 255, 0.60)" : "#9E9E9E",
      textTertiary: isDark ? "rgba(255, 255, 255, 0.38)" : "#C0C0C0",
      primary: isDark ? "#6B46C1" : "#10B981",
      border: isDark ? "#404040" : "#E6E6E6",
    },
  };

  const [favorites, setFavorites] = useState([]);

  const [fontsLoaded] = useFonts({
    Poppins_400Regular,
    Poppins_500Medium,
    Poppins_600SemiBold,
    Poppins_700Bold,
  });

  useEffect(() => {
    loadFavorites();
  }, []);

  const loadFavorites = async () => {
    try {
      const stored = await SecureStore.getItemAsync("favorites");
      if (stored) {
        setFavorites(JSON.parse(stored));
      }
    } catch (error) {
      console.error("Error loading favorites:", error);
    }
  };

  const { data: routesData } = useQuery({
    queryKey: ["routes"],
    queryFn: async () => {
      const response = await fetch("/api/bus/routes");
      if (!response.ok) throw new Error("Failed to fetch routes");
      const result = await response.json();
      return result.data || [];
    },
  });

  const toggleFavorite = async (routeId) => {
    try {
      const newFavorites = favorites.filter((id) => id !== routeId);
      setFavorites(newFavorites);
      await SecureStore.setItemAsync("favorites", JSON.stringify(newFavorites));
    } catch (error) {
      console.error("Error toggling favorite:", error);
    }
  };

  if (!fontsLoaded) {
    return null;
  }

  const favoriteRoutes =
    routesData?.filter((route) => favorites.includes(route.id)) || [];

  const handleRoutePress = (route) => {
    router.push(`/route/${route.id}`);
  };

  return (
    <View
      style={[
        styles.container,
        { backgroundColor: theme.colors.background, paddingTop: insets.top },
      ]}
    >
      <StatusBar style={theme.isDark ? "light" : "dark"} />

      <View style={styles.header}>
        <Text style={[styles.title, { color: theme.colors.text }]}>
          收藏路線
        </Text>
        <Text style={[styles.subtitle, { color: theme.colors.textSecondary }]}>
          {favoriteRoutes.length} 條路線
        </Text>
      </View>

      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={[
          styles.scrollContent,
          { paddingBottom: insets.bottom + 20 },
        ]}
        showsVerticalScrollIndicator={false}
      >
        {favoriteRoutes.length === 0 ? (
          <View style={styles.emptyContainer}>
            <Heart size={48} color={theme.colors.textTertiary} />
            <Text style={[styles.emptyText, { color: theme.colors.text }]}>
              沒有收藏路線
            </Text>
            <Text
              style={[
                styles.emptySubtext,
                { color: theme.colors.textSecondary },
              ]}
            >
              點擊心形圖示收藏路線
            </Text>
          </View>
        ) : (
          favoriteRoutes.map((route) => (
            <TouchableOpacity
              key={route.id}
              style={[
                styles.routeItem,
                {
                  backgroundColor: theme.colors.surface,
                  borderColor: theme.colors.border,
                },
              ]}
              onPress={() => handleRoutePress(route)}
              activeOpacity={0.7}
            >
              <View style={styles.routeLeft}>
                <View
                  style={[
                    styles.routeBadge,
                    {
                      backgroundColor:
                        route.company === "KMB" ? "#10B981" : "#3B82F6",
                    },
                  ]}
                >
                  <Text style={styles.routeNumber}>{route.route}</Text>
                </View>
                <View style={styles.routeInfo}>
                  <Text
                    style={[styles.routeText, { color: theme.colors.text }]}
                    numberOfLines={1}
                  >
                    {route.orig_tc} → {route.dest_tc}
                  </Text>
                  <Text
                    style={[
                      styles.routeCompany,
                      { color: theme.colors.textSecondary },
                    ]}
                  >
                    {route.company}
                  </Text>
                </View>
              </View>
              <TouchableOpacity
                onPress={() => toggleFavorite(route.id)}
                hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
              >
                <Heart size={20} color="#EF4444" fill="#EF4444" />
              </TouchableOpacity>
            </TouchableOpacity>
          ))
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    paddingHorizontal: 24,
    paddingTop: 20,
    paddingBottom: 16,
  },
  title: {
    fontFamily: "Poppins_700Bold",
    fontSize: 32,
    marginBottom: 4,
  },
  subtitle: {
    fontFamily: "Poppins_400Regular",
    fontSize: 16,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    paddingHorizontal: 24,
  },
  emptyContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    paddingTop: 60,
  },
  emptyText: {
    fontFamily: "Poppins_600SemiBold",
    fontSize: 18,
    marginTop: 16,
  },
  emptySubtext: {
    fontFamily: "Poppins_400Regular",
    fontSize: 14,
    marginTop: 8,
  },
  routeItem: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    padding: 16,
    borderRadius: 12,
    borderWidth: 1,
    marginBottom: 12,
  },
  routeLeft: {
    flexDirection: "row",
    alignItems: "center",
    flex: 1,
  },
  routeBadge: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 8,
    marginRight: 12,
  },
  routeNumber: {
    fontFamily: "Poppins_700Bold",
    fontSize: 16,
    color: "#FFFFFF",
  },
  routeInfo: {
    flex: 1,
  },
  routeText: {
    fontFamily: "Poppins_500Medium",
    fontSize: 14,
    marginBottom: 4,
  },
  routeCompany: {
    fontFamily: "Poppins_400Regular",
    fontSize: 12,
  },
});
