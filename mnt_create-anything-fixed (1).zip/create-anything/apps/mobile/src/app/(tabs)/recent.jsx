import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  StyleSheet,
  useColorScheme,
} from "react-native";
import { StatusBar } from "expo-status-bar";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import {
  useFonts,
  Poppins_400Regular,
  Poppins_500Medium,
  Poppins_600SemiBold,
  Poppins_700Bold,
} from "@expo-google-fonts/poppins";
import { Clock, Trash2 } from "lucide-react-native";
import { useRouter } from "expo-router";
import * as SecureStore from "expo-secure-store";

export default function RecentScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const colorScheme = useColorScheme();
  const isDark = colorScheme === "dark";

  const theme = {
    isDark,
    colors: {
      background: isDark ? "#121212" : "#FFFFFF",
      surface: isDark ? "#1E1E1E" : "#FFFFFF",
      surfaceElevated: isDark ? "#262626" : "#F5F5F5",
      text: isDark ? "rgba(255, 255, 255, 0.87)" : "#1A1A1A",
      textSecondary: isDark ? "rgba(255, 255, 255, 0.60)" : "#9E9E9E",
      textTertiary: isDark ? "rgba(255, 255, 255, 0.38)" : "#C0C0C0",
      primary: isDark ? "#6B46C1" : "#10B981",
      border: isDark ? "#404040" : "#E6E6E6",
    },
  };

  const [recentRoutes, setRecentRoutes] = useState([]);

  const [fontsLoaded] = useFonts({
    Poppins_400Regular,
    Poppins_500Medium,
    Poppins_600SemiBold,
    Poppins_700Bold,
  });

  useEffect(() => {
    loadRecent();
  }, []);

  const loadRecent = async () => {
    try {
      const stored = await SecureStore.getItemAsync("recent");
      if (stored) {
        setRecentRoutes(JSON.parse(stored));
      }
    } catch (error) {
      console.error("Error loading recent:", error);
    }
  };

  const clearRecent = async () => {
    try {
      await SecureStore.deleteItemAsync("recent");
      setRecentRoutes([]);
    } catch (error) {
      console.error("Error clearing recent:", error);
    }
  };

  const formatTime = (timestamp) => {
    const now = Date.now();
    const diff = now - timestamp;
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);

    if (minutes < 1) return "剛剛";
    if (minutes < 60) return `${minutes} 分鐘前`;
    if (hours < 24) return `${hours} 小時前`;
    return `${days} 天前`;
  };

  const handleRoutePress = (route) => {
    router.push(`/route/${route.id}`);
  };

  if (!fontsLoaded) {
    return null;
  }

  return (
    <View
      style={[
        styles.container,
        { backgroundColor: theme.colors.background, paddingTop: insets.top },
      ]}
    >
      <StatusBar style={theme.isDark ? "light" : "dark"} />

      <View style={styles.header}>
        <View>
          <Text style={[styles.title, { color: theme.colors.text }]}>
            最近瀏覽
          </Text>
          <Text
            style={[styles.subtitle, { color: theme.colors.textSecondary }]}
          >
            {recentRoutes.length} 條記錄
          </Text>
        </View>
        {recentRoutes.length > 0 && (
          <TouchableOpacity
            style={[
              styles.clearButton,
              { backgroundColor: theme.colors.surfaceElevated },
            ]}
            onPress={clearRecent}
            activeOpacity={0.7}
          >
            <Trash2 size={20} color={theme.colors.text} />
          </TouchableOpacity>
        )}
      </View>

      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={[
          styles.scrollContent,
          { paddingBottom: insets.bottom + 20 },
        ]}
        showsVerticalScrollIndicator={false}
      >
        {recentRoutes.length === 0 ? (
          <View style={styles.emptyContainer}>
            <Clock size={48} color={theme.colors.textTertiary} />
            <Text style={[styles.emptyText, { color: theme.colors.text }]}>
              沒有瀏覽記錄
            </Text>
            <Text
              style={[
                styles.emptySubtext,
                { color: theme.colors.textSecondary },
              ]}
            >
              查看路線後會自動記錄
            </Text>
          </View>
        ) : (
          recentRoutes.map((route, index) => (
            <TouchableOpacity
              key={`${route.id}-${index}`}
              style={[
                styles.routeItem,
                {
                  backgroundColor: theme.colors.surface,
                  borderColor: theme.colors.border,
                },
              ]}
              onPress={() => handleRoutePress(route)}
              activeOpacity={0.7}
            >
              <View style={styles.routeLeft}>
                <View
                  style={[
                    styles.routeBadge,
                    {
                      backgroundColor:
                        route.company === "KMB" ? "#10B981" : "#3B82F6",
                    },
                  ]}
                >
                  <Text style={styles.routeNumber}>{route.route}</Text>
                </View>
                <View style={styles.routeInfo}>
                  <Text
                    style={[styles.routeText, { color: theme.colors.text }]}
                    numberOfLines={1}
                  >
                    {route.orig_tc} → {route.dest_tc}
                  </Text>
                  <Text
                    style={[
                      styles.routeTime,
                      { color: theme.colors.textSecondary },
                    ]}
                  >
                    {formatTime(route.timestamp)}
                  </Text>
                </View>
              </View>
            </TouchableOpacity>
          ))
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: 24,
    paddingTop: 20,
    paddingBottom: 16,
  },
  title: {
    fontFamily: "Poppins_700Bold",
    fontSize: 32,
    marginBottom: 4,
  },
  subtitle: {
    fontFamily: "Poppins_400Regular",
    fontSize: 16,
  },
  clearButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    justifyContent: "center",
    alignItems: "center",
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    paddingHorizontal: 24,
  },
  emptyContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    paddingTop: 60,
  },
  emptyText: {
    fontFamily: "Poppins_600SemiBold",
    fontSize: 18,
    marginTop: 16,
  },
  emptySubtext: {
    fontFamily: "Poppins_400Regular",
    fontSize: 14,
    marginTop: 8,
  },
  routeItem: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    padding: 16,
    borderRadius: 12,
    borderWidth: 1,
    marginBottom: 12,
  },
  routeLeft: {
    flexDirection: "row",
    alignItems: "center",
    flex: 1,
  },
  routeBadge: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 8,
    marginRight: 12,
  },
  routeNumber: {
    fontFamily: "Poppins_700Bold",
    fontSize: 16,
    color: "#FFFFFF",
  },
  routeInfo: {
    flex: 1,
  },
  routeText: {
    fontFamily: "Poppins_500Medium",
    fontSize: 14,
    marginBottom: 4,
  },
  routeTime: {
    fontFamily: "Poppins_400Regular",
    fontSize: 12,
  },
});
