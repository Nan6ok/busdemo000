import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  TextInput,
  ScrollView,
  TouchableOpacity,
  StyleSheet,
  ActivityIndicator,
  useColorScheme,
} from "react-native";
import { StatusBar } from "expo-status-bar";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import {
  useFonts,
  Poppins_400Regular,
  Poppins_500Medium,
  Poppins_600SemiBold,
  Poppins_700Bold,
} from "@expo-google-fonts/poppins";
import { Search, Heart } from "lucide-react-native";
import { useRouter } from "expo-router";
import { useQuery } from "@tanstack/react-query";
import * as SecureStore from "expo-secure-store";

export default function HomeScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const colorScheme = useColorScheme();
  const isDark = colorScheme === "dark";

  const theme = {
    isDark,
    colors: {
      background: isDark ? "#121212" : "#FFFFFF",
      surface: isDark ? "#1E1E1E" : "#FFFFFF",
      surfaceElevated: isDark ? "#262626" : "#F5F5F5",
      text: isDark ? "rgba(255, 255, 255, 0.87)" : "#1A1A1A",
      textSecondary: isDark ? "rgba(255, 255, 255, 0.60)" : "#9E9E9E",
      textTertiary: isDark ? "rgba(255, 255, 255, 0.38)" : "#C0C0C0",
      primary: isDark ? "#6B46C1" : "#10B981",
      border: isDark ? "#404040" : "#E6E6E6",
    },
  };

  const [searchQuery, setSearchQuery] = useState("");
  const [favorites, setFavorites] = useState([]);

  const [fontsLoaded] = useFonts({
    Poppins_400Regular,
    Poppins_500Medium,
    Poppins_600SemiBold,
    Poppins_700Bold,
  });

  useEffect(() => {
    loadFavorites();
  }, []);

  const loadFavorites = async () => {
    try {
      const stored = await SecureStore.getItemAsync("favorites");
      if (stored) {
        setFavorites(JSON.parse(stored));
      }
    } catch (error) {
      console.error("Error loading favorites:", error);
    }
  };

  const toggleFavorite = async (routeId) => {
    try {
      let newFavorites;
      if (favorites.includes(routeId)) {
        newFavorites = favorites.filter((id) => id !== routeId);
      } else {
        newFavorites = [...favorites, routeId];
      }
      setFavorites(newFavorites);
      await SecureStore.setItemAsync("favorites", JSON.stringify(newFavorites));
    } catch (error) {
      console.error("Error toggling favorite:", error);
    }
  };

  const { data: routesData, isLoading } = useQuery({
    queryKey: ["routes"],
    queryFn: async () => {
      const response = await fetch("/api/bus/routes");
      if (!response.ok) throw new Error("Failed to fetch routes");
      const result = await response.json();
      return result.data || [];
    },
  });

  if (!fontsLoaded) {
    return null;
  }

  const filteredRoutes =
    routesData?.filter((route) => {
      if (!searchQuery) return true;
      const query = searchQuery.toLowerCase();
      return (
        route.route.toLowerCase().includes(query) ||
        route.orig_tc.includes(searchQuery) ||
        route.dest_tc.includes(searchQuery) ||
        route.orig_en.toLowerCase().includes(query) ||
        route.dest_en.toLowerCase().includes(query)
      );
    }) || [];

  const popularRoutes = filteredRoutes.slice(0, 6);

  const handleRoutePress = (route) => {
    router.push(`/route/${route.id}`);
  };

  return (
    <View
      style={[
        styles.container,
        { backgroundColor: theme.colors.background, paddingTop: insets.top },
      ]}
    >
      <StatusBar style={theme.isDark ? "light" : "dark"} />

      <View style={styles.header}>
        <Text style={[styles.title, { color: theme.colors.text }]}>
          香港巴士
        </Text>
        <Text style={[styles.subtitle, { color: theme.colors.textSecondary }]}>
          即時到站資訊
        </Text>
      </View>

      <View
        style={[
          styles.searchContainer,
          { backgroundColor: theme.colors.surfaceElevated },
        ]}
      >
        <Search size={20} color={theme.colors.textSecondary} />
        <TextInput
          style={[styles.searchInput, { color: theme.colors.text }]}
          placeholder="搜尋路線、起點或終點"
          placeholderTextColor={theme.colors.textSecondary}
          value={searchQuery}
          onChangeText={setSearchQuery}
        />
      </View>

      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={[
          styles.scrollContent,
          { paddingBottom: insets.bottom + 20 },
        ]}
        showsVerticalScrollIndicator={false}
      >
        <Text style={[styles.sectionTitle, { color: theme.colors.text }]}>
          熱門路線
        </Text>

        {isLoading ? (
          <ActivityIndicator
            size="large"
            color={theme.colors.primary}
            style={styles.loader}
          />
        ) : (
          <View style={styles.routeGrid}>
            {popularRoutes.map((route) => (
              <TouchableOpacity
                key={route.id}
                style={[
                  styles.routeCard,
                  {
                    backgroundColor: theme.colors.surface,
                    borderColor: theme.colors.border,
                  },
                ]}
                onPress={() => handleRoutePress(route)}
                activeOpacity={0.7}
              >
                <View style={styles.routeHeader}>
                  <View
                    style={[
                      styles.routeBadge,
                      {
                        backgroundColor:
                          route.company === "KMB" ? "#10B981" : "#3B82F6",
                      },
                    ]}
                  >
                    <Text style={styles.routeNumber}>{route.route}</Text>
                  </View>
                  <TouchableOpacity
                    onPress={() => toggleFavorite(route.id)}
                    hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
                  >
                    <Heart
                      size={20}
                      color={
                        favorites.includes(route.id)
                          ? "#EF4444"
                          : theme.colors.textSecondary
                      }
                      fill={
                        favorites.includes(route.id) ? "#EF4444" : "transparent"
                      }
                    />
                  </TouchableOpacity>
                </View>
                <Text
                  style={[styles.routeOrigin, { color: theme.colors.text }]}
                  numberOfLines={1}
                >
                  {route.orig_tc}
                </Text>
                <Text
                  style={[
                    styles.routeArrow,
                    { color: theme.colors.textSecondary },
                  ]}
                >
                  ↓
                </Text>
                <Text
                  style={[styles.routeDest, { color: theme.colors.text }]}
                  numberOfLines={1}
                >
                  {route.dest_tc}
                </Text>
                <Text
                  style={[
                    styles.routeCompany,
                    { color: theme.colors.textSecondary },
                  ]}
                >
                  {route.company}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    paddingHorizontal: 24,
    paddingTop: 20,
    paddingBottom: 16,
  },
  title: {
    fontFamily: "Poppins_700Bold",
    fontSize: 32,
    marginBottom: 4,
  },
  subtitle: {
    fontFamily: "Poppins_400Regular",
    fontSize: 16,
  },
  searchContainer: {
    flexDirection: "row",
    alignItems: "center",
    marginHorizontal: 24,
    marginBottom: 24,
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderRadius: 12,
  },
  searchInput: {
    flex: 1,
    marginLeft: 12,
    fontFamily: "Poppins_400Regular",
    fontSize: 16,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    paddingHorizontal: 24,
  },
  sectionTitle: {
    fontFamily: "Poppins_600SemiBold",
    fontSize: 20,
    marginBottom: 16,
  },
  loader: {
    marginTop: 40,
  },
  routeGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    marginHorizontal: -8,
  },
  routeCard: {
    width: "50%",
    padding: 16,
    borderRadius: 12,
    borderWidth: 1,
    marginBottom: 16,
    marginHorizontal: 8,
  },
  routeHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 12,
  },
  routeBadge: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 8,
  },
  routeNumber: {
    fontFamily: "Poppins_700Bold",
    fontSize: 16,
    color: "#FFFFFF",
  },
  routeOrigin: {
    fontFamily: "Poppins_500Medium",
    fontSize: 14,
    marginBottom: 4,
  },
  routeArrow: {
    fontFamily: "Poppins_400Regular",
    fontSize: 12,
    marginBottom: 4,
  },
  routeDest: {
    fontFamily: "Poppins_500Medium",
    fontSize: 14,
    marginBottom: 8,
  },
  routeCompany: {
    fontFamily: "Poppins_400Regular",
    fontSize: 12,
  },
});
