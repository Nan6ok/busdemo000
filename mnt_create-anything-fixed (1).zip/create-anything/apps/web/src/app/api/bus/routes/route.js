// 獲取所有 KMB + CTB 巴士路線
export async function GET(request) {
  try {
    // 獲取 KMB 路線
    const kmbResponse = await fetch(
      "https://data.etabus.gov.hk/v1/transport/kmb/route/",
    );
    if (!kmbResponse.ok) {
      throw new Error("Failed to fetch KMB routes");
    }
    const kmbData = await kmbResponse.json();

    // 獲取 CTB 路線
    const ctbResponse = await fetch(
      "https://rt.data.gov.hk/v2/transport/citybus/route/ctb",
    );
    if (!ctbResponse.ok) {
      throw new Error("Failed to fetch CTB routes");
    }
    const ctbData = await ctbResponse.json();

    // 合併並格式化路線數據
    const kmbRoutes = (kmbData.data || []).map((route) => ({
      id: `kmb-${route.route}-${route.bound}-${route.service_type}`,
      route: route.route,
      bound: route.bound,
      service_type: route.service_type,
      orig_tc: route.orig_tc,
      orig_en: route.orig_en,
      dest_tc: route.dest_tc,
      dest_en: route.dest_en,
      company: "KMB",
    }));

    const ctbRoutes = (ctbData.data || []).map((route) => ({
      id: `ctb-${route.route}-${route.bound}`,
      route: route.route,
      bound: route.bound,
      service_type: route.service_type || "1",
      orig_tc: route.orig_tc,
      orig_en: route.orig_en,
      dest_tc: route.dest_tc,
      dest_en: route.dest_en,
      company: "CTB",
    }));

    const allRoutes = [...kmbRoutes, ...ctbRoutes];

    return Response.json({
      success: true,
      data: allRoutes,
      count: allRoutes.length,
    });
  } catch (error) {
    console.error("Error fetching bus routes:", error);
    return Response.json(
      {
        success: false,
        error: error.message,
      },
      { status: 500 },
    );
  }
}
