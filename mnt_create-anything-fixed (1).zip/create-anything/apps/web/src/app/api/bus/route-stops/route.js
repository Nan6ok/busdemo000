// 獲取指定路線的所有巴士站
export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const route = searchParams.get("route");
    const bound = searchParams.get("bound");
    const serviceType = searchParams.get("service_type") || "1";
    const company = searchParams.get("company") || "KMB";

    if (!route || !bound) {
      return Response.json(
        {
          success: false,
          error: "Missing route or bound parameter",
        },
        { status: 400 },
      );
    }

    let stops = [];

    if (company === "KMB") {
      // 獲取 KMB 路線站點
      const routeStopUrl = `https://data.etabus.gov.hk/v1/transport/kmb/route-stop/${route}/${bound}/${serviceType}`;
      const routeStopResponse = await fetch(routeStopUrl);

      if (!routeStopResponse.ok) {
        throw new Error("Failed to fetch KMB route stops");
      }

      const routeStopData = await routeStopResponse.json();
      const stopList = routeStopData.data || [];

      // 獲取每個站點的詳細資訊
      for (const stopInfo of stopList) {
        try {
          const stopDetailUrl = `https://data.etabus.gov.hk/v1/transport/kmb/stop/${stopInfo.stop}`;
          const stopDetailResponse = await fetch(stopDetailUrl);

          if (stopDetailResponse.ok) {
            const stopDetailData = await stopDetailResponse.json();
            const stopDetail = stopDetailData.data;

            const lat = parseFloat(stopDetail.lat);
            const long = parseFloat(stopDetail.long);

            // Skip stops with invalid coordinates
            if (isNaN(lat) || isNaN(long)) {
              console.warn(`Invalid coordinates for stop ${stopInfo.stop}`);
              continue;
            }

            stops.push({
              seq: stopInfo.seq,
              stop: stopInfo.stop,
              name_tc: stopDetail.name_tc,
              name_en: stopDetail.name_en,
              lat: lat,
              long: long,
            });
          } else {
            console.warn(`Failed to fetch details for stop ${stopInfo.stop}: ${stopDetailResponse.status}`);
          }
        } catch (stopError) {
          console.warn(`Error fetching stop ${stopInfo.stop}:`, stopError.message);
        }
      }
    } else if (company === "CTB") {
      // 獲取 CTB 路線站點
      const routeStopUrl = `https://rt.data.gov.hk/v2/transport/citybus/route-stop/ctb/${route}/${bound}`;
      const routeStopResponse = await fetch(routeStopUrl);

      if (!routeStopResponse.ok) {
        throw new Error("Failed to fetch CTB route stops");
      }

      const routeStopData = await routeStopResponse.json();
      const stopList = routeStopData.data || [];

      // 獲取每個站點的詳細資訊
      for (const stopInfo of stopList) {
        try {
          const stopDetailUrl = `https://rt.data.gov.hk/v2/transport/citybus/stop/${stopInfo.stop}`;
          const stopDetailResponse = await fetch(stopDetailUrl);

          if (stopDetailResponse.ok) {
            const stopDetailData = await stopDetailResponse.json();
            const stopDetail = stopDetailData.data;

            const lat = parseFloat(stopDetail.lat);
            const long = parseFloat(stopDetail.long);

            // Skip stops with invalid coordinates
            if (isNaN(lat) || isNaN(long)) {
              console.warn(`Invalid coordinates for stop ${stopInfo.stop}`);
              continue;
            }

            stops.push({
              seq: stopInfo.seq,
              stop: stopInfo.stop,
              name_tc: stopDetail.name_tc,
              name_en: stopDetail.name_en,
              lat: lat,
              long: long,
            });
          } else {
            console.warn(`Failed to fetch details for stop ${stopInfo.stop}: ${stopDetailResponse.status}`);
          }
        } catch (stopError) {
          console.warn(`Error fetching stop ${stopInfo.stop}:`, stopError.message);
        }
      }
    }

    // 按順序排序
    stops.sort((a, b) => a.seq - b.seq);

    return Response.json({
      success: true,
      data: stops,
      count: stops.length,
    });
  } catch (error) {
    console.error("Error fetching route stops:", error);
    return Response.json(
      {
        success: false,
        error: error.message,
      },
      { status: 500 },
    );
  }
}
