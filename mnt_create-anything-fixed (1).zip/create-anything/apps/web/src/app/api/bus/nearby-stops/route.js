// 獲取附近的巴士站
export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const lat = parseFloat(searchParams.get("lat"));
    const long = parseFloat(searchParams.get("long"));
    const radius = parseFloat(searchParams.get("radius")) || 500; // 預設 500 米

    if (!lat || !long) {
      return Response.json(
        {
          success: false,
          error: "Missing lat or long parameter",
        },
        { status: 400 },
      );
    }

    // 獲取所有 KMB 站點
    const kmbStopsResponse = await fetch(
      "https://data.etabus.gov.hk/v1/transport/kmb/stop",
    );
    if (!kmbStopsResponse.ok) {
      throw new Error("Failed to fetch KMB stops");
    }
    const kmbStopsData = await kmbStopsResponse.json();
    const kmbStops = kmbStopsData.data || [];

    // 獲取所有 CTB 站點
    const ctbStopsResponse = await fetch(
      "https://rt.data.gov.hk/v2/transport/citybus/stop/ctb",
    );
    if (!ctbStopsResponse.ok) {
      throw new Error("Failed to fetch CTB stops");
    }
    const ctbStopsData = await ctbStopsResponse.json();
    const ctbStops = ctbStopsData.data || [];

    // 計算距離的函數 (Haversine formula)
    function calculateDistance(lat1, lon1, lat2, lon2) {
      const R = 6371e3; // 地球半徑（米）
      const φ1 = (lat1 * Math.PI) / 180;
      const φ2 = (lat2 * Math.PI) / 180;
      const Δφ = ((lat2 - lat1) * Math.PI) / 180;
      const Δλ = ((lon2 - lon1) * Math.PI) / 180;

      const a =
        Math.sin(Δφ / 2) * Math.sin(Δφ / 2) +
        Math.cos(φ1) * Math.cos(φ2) * Math.sin(Δλ / 2) * Math.sin(Δλ / 2);
      const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

      return R * c;
    }

    // 處理 KMB 站點
    const nearbyKmbStops = kmbStops
      .map((stop) => {
        const stopLat = parseFloat(stop.lat);
        const stopLong = parseFloat(stop.long);

        // Skip stops with invalid coordinates
        if (isNaN(stopLat) || isNaN(stopLong)) {
          return null;
        }

        const distance = calculateDistance(lat, long, stopLat, stopLong);

        return {
          stop: stop.stop,
          name_tc: stop.name_tc,
          name_en: stop.name_en,
          lat: stopLat,
          long: stopLong,
          distance: Math.round(distance),
          company: "KMB",
        };
      })
      .filter((stop) => stop !== null && stop.distance <= radius);

    // 處理 CTB 站點
    const nearbyCtbStops = ctbStops
      .map((stop) => {
        const stopLat = parseFloat(stop.lat);
        const stopLong = parseFloat(stop.long);

        // Skip stops with invalid coordinates
        if (isNaN(stopLat) || isNaN(stopLong)) {
          return null;
        }

        const distance = calculateDistance(lat, long, stopLat, stopLong);

        return {
          stop: stop.stop,
          name_tc: stop.name_tc,
          name_en: stop.name_en,
          lat: stopLat,
          long: stopLong,
          distance: Math.round(distance),
          company: "CTB",
        };
      })
      .filter((stop) => stop !== null && stop.distance <= radius);

    // 合併並按距離排序
    const allNearbyStops = [...nearbyKmbStops, ...nearbyCtbStops]
      .sort((a, b) => a.distance - b.distance)
      .slice(0, 20); // 最多返回 20 個站點

    return Response.json({
      success: true,
      data: allNearbyStops,
      count: allNearbyStops.length,
    });
  } catch (error) {
    console.error("Error fetching nearby stops:", error);
    return Response.json(
      {
        success: false,
        error: error.message,
      },
      { status: 500 },
    );
  }
}
