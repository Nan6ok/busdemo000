// 獲取指定站點的即時到站時間 (ETA)
export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const stop = searchParams.get("stop");
    const route = searchParams.get("route");
    const serviceType = searchParams.get("service_type") || "1";
    const company = searchParams.get("company") || "KMB";

    if (!stop || !route) {
      return Response.json(
        {
          success: false,
          error: "Missing stop or route parameter",
        },
        { status: 400 },
      );
    }

    let etaData = [];

    if (company === "KMB") {
      const etaUrl = `https://data.etabus.gov.hk/v1/transport/kmb/stop-eta/${stop}`;
      const etaResponse = await fetch(etaUrl);

      if (!etaResponse.ok) {
        throw new Error("Failed to fetch KMB ETA");
      }

      const etaResult = await etaResponse.json();
      const allEtas = etaResult.data || [];

      // 過濾出指定路線的 ETA
      etaData = allEtas
        .filter(
          (eta) =>
            eta.route === route && eta.service_type === parseInt(serviceType),
        )
        .map((eta) => ({
          eta: eta.eta,
          eta_seq: eta.eta_seq,
          rmk_tc: eta.rmk_tc,
          rmk_en: eta.rmk_en,
        }))
        .slice(0, 3); // 最多顯示 3 班巴士
    } else if (company === "CTB") {
      const etaUrl = `https://rt.data.gov.hk/v2/transport/citybus/eta/ctb/${stop}/${route}`;
      const etaResponse = await fetch(etaUrl);

      if (!etaResponse.ok) {
        throw new Error("Failed to fetch CTB ETA");
      }

      const etaResult = await etaResponse.json();
      const allEtas = etaResult.data || [];

      etaData = allEtas
        .map((eta) => ({
          eta: eta.eta,
          eta_seq: eta.seq,
          rmk_tc: eta.rmk_tc,
          rmk_en: eta.rmk_en,
        }))
        .slice(0, 3);
    }

    return Response.json({
      success: true,
      data: etaData,
    });
  } catch (error) {
    console.error("Error fetching ETA:", error);
    return Response.json(
      {
        success: false,
        error: error.message,
      },
      { status: 500 },
    );
  }
}
